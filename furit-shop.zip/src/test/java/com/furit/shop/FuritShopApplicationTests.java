package com.furit.shop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FuritShopApplicationTests {

	@Test
	void contextLoads() {
	}

}
